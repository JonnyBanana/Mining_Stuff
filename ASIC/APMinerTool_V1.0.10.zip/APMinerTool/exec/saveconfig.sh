#!/bin/sh -e


if [ ! -d /mnt/config ];then
	mkdir /mnt/config
fi

ubiattach /dev/ubi_ctrl -m 2
mount -t ubifs ubi1:rootfs /mnt/config
if [ ! -d /mnt/config/home/usr_config ];then
	mkdir /mnt/config/home/usr_config
fi

cp -r /config/bmminer.conf /mnt/config/home/usr_config/
cp -r /config/network.conf /mnt/config/home/usr_config/
cp -r /config/mac /mnt/config/home/usr_config/
cp -r /config/shadow /mnt/config/home/usr_config/
cp -r /config/lighttpd-htdigest.user /mnt/config/home/usr_config/
echo "NO_START=1" > /mnt/config/home/usr_config/dropbear
umount /mnt/config
ubidetach -d 1 /dev/ubi_ctrl
