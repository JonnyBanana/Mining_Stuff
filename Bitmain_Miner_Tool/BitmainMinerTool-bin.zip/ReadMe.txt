This package is binary of application without installation process.

1. Application file: BitMainMinerTool.exe
2. If you have changed the miner's web login password, you must change the BitMainMinerTool.exe.config file before you use this tools
  <common_web>
    <add key="user" value="root"/>
    <add key="pass" value="root"/>      // you can change this pass here!
  </common_web>
   must exit application and restart again!

3. In windows XP, when you run application, you maybe be asked to download DOT NET framework. After install DOT NET framework, you can use this tool.

