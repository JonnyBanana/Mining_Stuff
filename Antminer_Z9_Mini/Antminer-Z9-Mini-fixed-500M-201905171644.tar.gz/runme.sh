#set -x
file=/tmp/$$
if [ ! -f cert.pem.sig ]; then
	echo "RUNME: Cannot Find Cert Signature!!!">> /tmp/upgrade_result
	exit 1
fi	
if [ ! -f cert.pem ]; then
	echo "RUNME: Cannot Find Cert!!!">> /tmp/upgrade_result
	exit 1
fi

if [ -e /etc/bitmain-pub.pem ]; then
	openssl dgst -sha256 -verify /etc/bitmain-pub.pem -signature  cert.pem.sig  cert.pem >/dev/null  2>&1
	vres=$?
	if [ $vres -eq 1 ]; then
		echo "RUNME: Cert Failed!!!" >> /tmp/upgrade_result
		exit 2
	fi
fi

if [ ! -f fileinfo.sig ]; then
		echo "RUNME: Cannot Find Signature!!!" >> /tmp/upgrade_result
		exit 1
fi
if [ ! -f fileinfo ]; then
	echo "RUNME: Cannot Find FileList!!!" >> /tmp/upgrade_result
	exit 1
fi	

openssl dgst -sha256 -verify cert.pem -signature  fileinfo.sig  fileinfo >/dev/null  2>&1
vres=$?
if [ $vres -eq 1 ]; then
	echo "RUNME: FileList Not Signtured!!!" >> /tmp/upgrade_result
	exit 2
fi	
md5sum -s -c fileinfo 
vres=$?
if [ $vres -eq 1 ]; then
	echo "RUNME: FileList Check Failed!!!" >> /tmp/upgrade_result
	exit 3
fi
if [ -e /etc/ant_version ]; then
	nVer=`cat version`
	oVer=`cat /etc/ant_version`

	if [ ${nVer} -lt ${oVer} ]; then
		echo "RUNME: Cannot Downgrade!!!" >> /tmp/upgrade_result
		exit 4
	fi	
fi

if [ -e BOOT.bin ]; then
	grep -w "BOOT.bin" fileinfo >/dev/null  2>&1
	vres=$?
	if [ $vres -eq 1 ]; then
		echo "RUNME: BOOT.bin NOT SIGNED!" >> /tmp/upgrade_result
		exit 5
	fi
	flash_erase /dev/mtd0 0x0 0x40 >/dev/null 2>&1
	nandwrite -p -s 0x0 /dev/mtd0 BOOT.bin >/dev/null 2>&1
fi

if [ -e devicetree.dtb ]; then
	grep -w "devicetree.dtb" fileinfo >/dev/null  2>&1
	vres=$?
	if [ $vres -eq 1 ]; then
		echo "RUNME:  devicetree.dtb NOT SIGNED!" >> /tmp/upgrade_result
		exit 6
	fi
	flash_erase /dev/mtd0 0x1A00000 0x1 >/dev/null 2>&1
	nandwrite -p -s 0x1A00000 /dev/mtd0 devicetree.dtb >/dev/null 2>&1
fi

if [ -e uImage ]; then
	grep -w "uImage" fileinfo >/dev/null  2>&1
	vres=$?
	if [ $vres -eq 1 ]; then
		echo "RUNME:  uImage.dtb NOT SIGNED!" >> /tmp/upgrade_result
		exit 6
	fi
	flash_erase /dev/mtd0 0x2000000 0x40 >/dev/null 2>&1
	nandwrite -p -s 0x2000000 /dev/mtd0 uImage >/dev/null 2>&1
fi

if [ -e uramdisk.image.gz ]; then
		grep -w "uramdisk.image.gz" fileinfo >/dev/null  2>&1
		vres=$?
		if [ $vres -eq 1 ]; then
			echo "RUNME: uramdisk.image.gz NOT SIGNED!" >> /tmp/upgrade_result
			exit 5
		fi	
    md5=`md5sum uramdisk.image.gz | awk {'print $1'}`
    md5_r=`cat md5_info`
    if [ $md5 == $md5_r ];then
		flash_erase /dev/mtd1 0x0 0x100 >/dev/null 2>&1
		nandwrite -p -s 0x0 /dev/mtd1 uramdisk.image.gz >/dev/null 2>&1
		if [ -e /dev/mtd4 ]; then
			flash_erase /dev/mtd4 0x0 0x100 >/dev/null 2>&1
			nandwrite -p -s 0x0 /dev/mtd4 uramdisk.image.gz >/dev/null 2>&1
		fi
	else
		echo $md5 > /config/md5_error
		echo $md5_r >> /config/md5_error
		echo "Error md5! $md5 $md5_r" >> /tmp/upgrade_result
	fi
fi

sync >/dev/null 2>&1