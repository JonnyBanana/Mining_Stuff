#!/bin/sh
b58=$(base58 1)
test x$b58 = xr
