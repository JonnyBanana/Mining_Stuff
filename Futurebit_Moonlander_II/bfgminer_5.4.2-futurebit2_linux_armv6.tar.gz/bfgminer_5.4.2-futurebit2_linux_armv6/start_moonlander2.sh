./bfgminer --scrypt -o stratum+tcp://us.litecoinpool.org:3333 -u jstefanop.1 -p 1,d=128 -S ALL --set MLD:clock=600
